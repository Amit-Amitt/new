import React, { useState, useEffect } from "react";
import { LostItem, FoundItem, User } from "@/entities/all";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Search, 
  MapPin, 
  Calendar,
  TrendingUp,
  Users,
  CheckCircle,
  AlertCircle,
  Plus
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { format } from "date-fns";

import QuickActions from "../Components/Dashboard/QuickActions";
import RecentActivity from "../Components/Dashboard/RecentActivity";
import StatsOverview from "../Components/Dashboard/StatsOverview";

export default function Dashboard() {
  const [lostItems, setLostItems] = useState([]);
  const [foundItems, setFoundItems] = useState([]);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [lostData, foundData, userData] = await Promise.all([
        LostItem.list('-created_date', 10),
        FoundItem.list('-created_date', 10),
        User.me().catch(() => null)
      ]);
      
      setLostItems(lostData);
      setFoundItems(foundData);
      setUser(userData);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const stats = {
    totalLost: lostItems.length,
    totalFound: foundItems.length,
    activeItems: lostItems.filter(item => item.status === 'active').length + 
                 foundItems.filter(item => item.status === 'available').length,
    successfulReturns: lostItems.filter(item => item.status === 'found').length +
                      foundItems.filter(item => item.status === 'returned').length
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <div className="max-w-7xl mx-auto p-6 space-y-8">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-8"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Welcome to Campus Lost & Found
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Connecting our college community to reunite lost items with their owners
          </p>
        </motion.div>

        {/* Quick Actions */}
        <QuickActions />

        {/* Stats Overview */}
        <StatsOverview 
          stats={stats}
          isLoading={isLoading}
        />

        {/* Recent Activity */}
        <div className="grid lg:grid-cols-2 gap-8">
          <RecentActivity 
            title="Recent Lost Items"
            items={lostItems.slice(0, 5)}
            type="lost"
            isLoading={isLoading}
          />
          <RecentActivity 
            title="Recent Found Items"
            items={foundItems.slice(0, 5)}
            type="found"
            isLoading={isLoading}
          />
        </div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-3xl p-8 text-center text-white"
        >
          <h2 className="text-3xl font-bold mb-4">Can't Find Your Item?</h2>
          <p className="text-blue-100 mb-6 text-lg">
            Browse through all reported items or create a new report to get help from the community
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("Browse")}>
              <Button className="bg-white text-blue-600 hover:bg-blue-50 font-semibold px-8 py-3">
                <Search className="w-5 h-5 mr-2" />
                Browse All Items
              </Button>
            </Link>
            <Link to={createPageUrl("ReportLost")}>
              <Button variant="outline" className="border-white text-white hover:bg-white/10 font-semibold px-8 py-3">
                <Plus className="w-5 h-5 mr-2" />
                Report Lost Item
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}