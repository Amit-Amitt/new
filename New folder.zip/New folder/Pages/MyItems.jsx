import React, { useState, useEffect } from "react";
import { LostItem, FoundItem, User } from "@/entities/all";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { 
  User as UserIcon,
  AlertCircle,
  CheckCircle,
  Edit,
  Trash2,
  MapPin,
  Calendar,
  DollarSign,
  Image as ImageIcon,
  Phone,
  Mail
} from "lucide-react";
import { format } from "date-fns";
import { motion } from "framer-motion";

import UserProfile from "../components/profile/UserProfile";

export default function MyItems() {
  const [user, setUser] = useState(null);
  const [myLostItems, setMyLostItems] = useState([]);
  const [myFoundItems, setMyFoundItems] = useState([]);
  const [activeTab, setActiveTab] = useState("profile");
  const [isLoading, setIsLoading] = useState(true);
  const [deleteItem, setDeleteItem] = useState(null);
  const [updating, setUpdating] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const userData = await User.me();
      setUser(userData);
      
      // Filter items by current user
      const [allLost, allFound] = await Promise.all([
        LostItem.list('-created_date'),
        FoundItem.list('-created_date')
      ]);
      
      const userLost = allLost.filter(item => item.created_by === userData.email);
      const userFound = allFound.filter(item => item.created_by === userData.email);
      
      setMyLostItems(userLost);
      setMyFoundItems(userFound);
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleStatusUpdate = async (item, newStatus, type) => {
    setUpdating(item.id);
    try {
      if (type === 'lost') {
        await LostItem.update(item.id, { status: newStatus });
      } else {
        await FoundItem.update(item.id, { status: newStatus });
      }
      loadData(); // Reload data
    } catch (error) {
      console.error('Error updating status:', error);
    }
    setUpdating(null);
  };

  const handleDelete = async () => {
    if (!deleteItem) return;
    
    try {
      if (deleteItem.type === 'lost') {
        await LostItem.delete(deleteItem.id);
      } else {
        await FoundItem.delete(deleteItem.id);
      }
      loadData(); // Reload data
    } catch (error) {
      console.error('Error deleting item:', error);
    }
    setDeleteItem(null);
  };

  const getStatusOptions = (type, currentStatus) => {
    if (type === 'lost') {
      return [
        { value: 'active', label: 'Still Lost' },
        { value: 'found', label: 'Found' }
      ];
    } else {
      return [
        { value: 'available', label: 'Available' },
        { value: 'returned', label: 'Returned to Owner' }
      ];
    }
  };

  const categoryColors = {
    electronics: "bg-blue-100 text-blue-800",
    clothing: "bg-purple-100 text-purple-800", 
    books: "bg-green-100 text-green-800",
    accessories: "bg-pink-100 text-pink-800",
    keys: "bg-yellow-100 text-yellow-800",
    documents: "bg-red-100 text-red-800",
    sports_equipment: "bg-indigo-100 text-indigo-800",
    bags: "bg-orange-100 text-orange-800",
    jewelry: "bg-purple-100 text-purple-800",
    other: "bg-gray-100 text-gray-800"
  };

  const ItemCard = ({ item, type }) => {
    const statusInfo = type === 'lost' 
      ? { icon: item.status === 'found' ? CheckCircle : AlertCircle, color: item.status === 'found' ? 'text-green-600' : 'text-red-600' }
      : { icon: item.status === 'returned' ? CheckCircle : AlertCircle, color: item.status === 'returned' ? 'text-green-600' : 'text-orange-600' };
    
    const StatusIcon = statusInfo.icon;

    return (
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300">
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <h3 className="text-lg font-bold text-gray-900 mb-2">{item.title}</h3>
              <p className="text-gray-600 text-sm line-clamp-2 mb-3">{item.description}</p>
              
              <div className="flex flex-wrap gap-2 mb-3">
                <Badge className={categoryColors[item.category] || categoryColors.other}>
                  {item.category?.replace(/_/g, ' ')}
                </Badge>
                <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs ${statusInfo.color} bg-white/80`}>
                  <StatusIcon className="w-3 h-3" />
                  <span className="font-medium">
                    {type === 'lost' 
                      ? (item.status === 'found' ? 'Found' : 'Still Lost')
                      : (item.status === 'returned' ? 'Returned' : 'Available')
                    }
                  </span>
                </div>
              </div>

              <div className="space-y-1 text-sm text-gray-500">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  <span>{type === 'lost' ? item.location_lost : item.location_found}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  <span>{format(new Date(type === 'lost' ? item.date_lost : item.date_found), 'MMM d, yyyy')}</span>
                </div>
                {type === 'lost' && item.reward_offered && (
                  <div className="flex items-center gap-2 text-green-600 font-medium">
                    <DollarSign className="w-4 h-4" />
                    <span>${item.reward_offered} reward</span>
                  </div>
                )}
              </div>
            </div>

            {item.image_urls && item.image_urls.length > 0 && (
              <img
                src={item.image_urls[0]}
                alt={item.title}
                className="w-20 h-20 object-cover rounded-lg ml-4"
              />
            )}
          </div>

          <div className="flex items-center justify-between pt-4 border-t">
            <Select
              value={item.status}
              onValueChange={(value) => handleStatusUpdate(item, value, type)}
              disabled={updating === item.id}
            >
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {getStatusOptions(type, item.status).map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setDeleteItem({ id: item.id, type, title: item.title })}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 p-6">
      <div className="max-w-6xl mx-auto space-y-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-4">My Account</h1>
          <p className="text-xl text-gray-600">Manage your profile and track your reports</p>
        </motion.div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 h-12">
            <TabsTrigger value="profile" className="flex items-center gap-2">
              <UserIcon className="w-4 h-4" />
              Profile
            </TabsTrigger>
            <TabsTrigger value="lost" className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              My Lost Items ({myLostItems.length})
            </TabsTrigger>
            <TabsTrigger value="found" className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4" />
              My Found Items ({myFoundItems.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="profile">
            <UserProfile user={user} onUpdate={loadData} />
          </TabsContent>

          <TabsContent value="lost">
            <div className="space-y-6">
              {myLostItems.length === 0 ? (
                <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                  <CardContent className="text-center py-12">
                    <AlertCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">No Lost Items</h3>
                    <p className="text-gray-600">You haven't reported any lost items yet.</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {myLostItems.map((item, index) => (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <ItemCard item={item} type="lost" />
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="found">
            <div className="space-y-6">
              {myFoundItems.length === 0 ? (
                <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
                  <CardContent className="text-center py-12">
                    <CheckCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">No Found Items</h3>
                    <p className="text-gray-600">You haven't reported any found items yet.</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {myFoundItems.map((item, index) => (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <ItemCard item={item} type="found" />
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>

        {/* Delete Confirmation Dialog */}
        <AlertDialog open={!!deleteItem} onOpenChange={() => setDeleteItem(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Item Report</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete "{deleteItem?.title}"? This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}