import React, { useState, useEffect, useCallback } from "react";
import { LostItem, FoundItem } from "@/entities/all";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Search,
  Filter,
  MapPin,
  Calendar,
  Image as ImageIcon,
  Phone,
  Mail,
  AlertCircle,
  CheckCircle
} from "lucide-react";
import { format } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";

import ItemCard from "../components/browse/ItemCard";
import ItemFilters from "../components/browse/ItemFilters";
import { fuzzySearch, getSearchSuggestions } from "../components/utils/searchUtils"; // Corrected path

export default function Browse() {
  const [lostItems, setLostItems] = useState([]);
  const [foundItems, setFoundItems] = useState([]);
  const [filteredLostItems, setFilteredLostItems] = useState([]);
  const [filteredFoundItems, setFilteredFoundItems] = useState([]);
  const [activeTab, setActiveTab] = useState("lost");
  const [searchTerm, setSearchTerm] = useState("");
  const [filters, setFilters] = useState({
    category: "all",
    dateRange: "all",
    status: "all"
  });
  const [isLoading, setIsLoading] = useState(true);
  const [searchSuggestions, setSearchSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  useEffect(() => {
    loadItems();
  }, []);

  const loadItems = async () => {
    setIsLoading(true);
    try {
      const [lost, found] = await Promise.all([
        LostItem.list('-created_date'),
        FoundItem.list('-created_date')
      ]);
      setLostItems(lost);
      setFoundItems(found);
    } catch (error) {
      console.error('Error loading items:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const applyFilters = useCallback(() => {
    const currentItems = activeTab === "lost" ? lostItems : foundItems;

    let filtered = currentItems.filter(item => {
      // Enhanced fuzzy search
      const matchesSearch = searchTerm === "" ||
                          fuzzySearch(searchTerm, item.title) ||
                          fuzzySearch(searchTerm, item.description) ||
                          fuzzySearch(searchTerm, activeTab === "lost" ? item.location_lost : item.location_found) ||
                          fuzzySearch(searchTerm, item.category?.replace(/_/g, ' '));

      // Category filter
      const matchesCategory = filters.category === "all" || item.category === filters.category;

      // Status filter
      const matchesStatus = filters.status === "all" || item.status === filters.status;

      // Date range filter
      let matchesDate = true;
      if (filters.dateRange !== "all") {
        const itemDate = new Date(activeTab === "lost" ? item.date_lost : item.date_found);
        const today = new Date();
        const daysDiff = Math.floor((today - itemDate) / (1000 * 60 * 60 * 24));

        switch (filters.dateRange) {
          case "today":
            matchesDate = daysDiff === 0;
            break;
          case "week":
            matchesDate = daysDiff <= 7;
            break;
          case "month":
            matchesDate = daysDiff <= 30;
            break;
        }
      }

      return matchesSearch && matchesCategory && matchesStatus && matchesDate;
    });

    if (activeTab === "lost") {
      setFilteredLostItems(filtered);
    } else {
      setFilteredFoundItems(filtered);
    }
  }, [searchTerm, filters, lostItems, foundItems, activeTab]);

  const handleSearchChange = (value) => {
    setSearchTerm(value);

    if (value.length >= 2) {
      const suggestions = getSearchSuggestions(value);
      setSearchSuggestions(suggestions);
      setShowSuggestions(suggestions.length > 0);
    } else {
      setShowSuggestions(false);
    }
  };

  const selectSuggestion = (suggestion) => {
    setSearchTerm(suggestion);
    setShowSuggestions(false);
  };

  useEffect(() => {
    applyFilters();
  }, [applyFilters]);

  const currentItems = activeTab === "lost" ? filteredLostItems : filteredFoundItems;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Browse Items</h1>
          <p className="text-xl text-gray-600">
            Search through all lost and found items on campus
          </p>
        </motion.div>

        {/* Enhanced Search and Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 shadow-lg"
        >
          <div className="flex flex-col lg:flex-row gap-4 mb-6">
            <div className="flex-1 relative"> {/* This div is made relative to contain absolute suggestions */}
              <div className="relative">
                <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                <Input
                  placeholder="Search by item name, description, or location... (try 'lapi' for laptop)"
                  value={searchTerm}
                  onChange={(e) => handleSearchChange(e.target.value)}
                  onFocus={() => searchTerm.length >= 2 && setShowSuggestions(true)}
                  onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                  className="pl-10 h-12 text-lg border-2 focus:border-blue-400"
                />
              </div>

              {/* Search Suggestions */}
              {showSuggestions && (
                <div className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg max-h-48 overflow-y-auto">
                  {searchSuggestions.map((suggestion, idx) => (
                    <button
                      key={idx}
                      onClick={() => selectSuggestion(suggestion)}
                      className="w-full text-left px-4 py-2 hover:bg-blue-50 first:rounded-t-lg last:rounded-b-lg transition-colors"
                    >
                      <span className="text-sm font-medium text-gray-700">{suggestion}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <ItemFilters
              filters={filters}
              setFilters={setFilters}
              activeTab={activeTab}
            />
          </div>

          {/* Enhanced Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 h-14 bg-gray-100">
              <TabsTrigger value="lost" className="flex items-center gap-3 data-[state=active]:bg-red-50 data-[state=active]:text-red-700">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <AlertCircle className="w-5 h-5" />
                  <span className="font-semibold">Lost Items ({filteredLostItems.length})</span>
                </div>
              </TabsTrigger>
              <TabsTrigger value="found" className="flex items-center gap-3 data-[state=active]:bg-green-50 data-[state=active]:text-green-700">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  <CheckCircle className="w-5 h-5" />
                  <span className="font-semibold">Found Items ({filteredFoundItems.length})</span>
                </div>
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </motion.div>

        {/* Results */}
        <div className="space-y-6">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-white rounded-2xl p-6 h-80">
                    <div className="w-full h-40 bg-gray-200 rounded-lg mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded mb-4 w-3/4"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : currentItems.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-16"
            >
              <div className="w-24 h-24 mx-auto mb-6 bg-gray-100 rounded-full flex items-center justify-center">
                <Search className="w-12 h-12 text-gray-400" />
              </div>
              <h3 className="text-2xl font-semibold text-gray-900 mb-2">No items found</h3>
              <p className="text-gray-600 mb-6">
                Try adjusting your search terms or filters
              </p>
              <Button
                onClick={() => {
                  setSearchTerm("");
                  setFilters({ category: "all", dateRange: "all", status: "all" });
                }}
                variant="outline"
              >
                Clear All Filters
              </Button>
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              <AnimatePresence>
                {currentItems.map((item, index) => (
                  <ItemCard
                    key={item.id}
                    item={item}
                    type={activeTab}
                    index={index}
                  />
                ))}
              </AnimatePresence>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
}
