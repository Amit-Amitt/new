
import React, { useState, useEffect, useCallback } from "react";
import { Conversation, Message, User } from "@/entities/all";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { 
  MessageSquare,
  Send,
  ArrowLeft,
  User as UserIcon,
  Clock,
  CheckCheck
} from "lucide-react";
import { format } from "date-fns";
import { motion, AnimatePresence } from "framer-motion";

export default function Messages() {
  const [conversations, setConversations] = useState([]);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [sending, setSending] = useState(false);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const userData = await User.me();
      setUser(userData);
      
      const allConversations = await Conversation.list('-last_message_date');
      const userConversations = allConversations.filter(
        conv => conv.item_owner === userData.email || conv.inquirer === userData.email
      );
      
      setConversations(userConversations);
    } catch (error) {
      console.error('Error loading conversations:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadMessages = useCallback(async () => {
    if (!selectedConversation || !user) return; // Added check for user as well

    try {
      const allMessages = await Message.list('-created_date');
      const conversationMessages = allMessages.filter(
        msg => msg.conversation_id === selectedConversation.id
      ).reverse(); // Show oldest first
      
      setMessages(conversationMessages);
      
      // Mark messages as read
      const unreadMessages = conversationMessages.filter(
        msg => !msg.is_read && msg.sender !== user.email
      );
      
      for (const msg of unreadMessages) {
        await Message.update(msg.id, { is_read: true });
      }
    } catch (error) {
      console.error('Error loading messages:', error);
    }
  }, [selectedConversation, user]); // Dependencies for useCallback

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    loadMessages();
  }, [loadMessages]); // Dependency updated to loadMessages (which is now memoized)

  const sendMessage = async () => {
    if (!newMessage.trim() || !selectedConversation || sending) return;
    
    setSending(true);
    try {
      // Create new message
      await Message.create({
        conversation_id: selectedConversation.id,
        sender: user.email,
        content: newMessage.trim()
      });
      
      // Update conversation with last message
      await Conversation.update(selectedConversation.id, {
        last_message: newMessage.trim(),
        last_message_date: new Date().toISOString()
      });
      
      setNewMessage("");
      loadMessages();
      loadData(); // Refresh conversation list
    } catch (error) {
      console.error('Error sending message:', error);
    }
    setSending(false);
  };

  const getOtherUser = (conversation) => {
    return conversation.item_owner === user.email 
      ? conversation.inquirer 
      : conversation.item_owner;
  };

  const getUnreadCount = (conversation) => {
    return messages.filter(msg => 
      msg.conversation_id === conversation.id && 
      !msg.is_read && 
      msg.sender !== user.email
    ).length;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      <div className="max-w-7xl mx-auto p-6">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Messages</h1>
          <p className="text-xl text-gray-600">Chat anonymously about lost and found items</p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
          {/* Conversations List */}
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl overflow-hidden">
            <CardHeader className="border-b">
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                Conversations
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0 h-full overflow-y-auto">
              {conversations.length === 0 ? (
                <div className="text-center py-12 px-6">
                  <MessageSquare className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">No Conversations</h3>
                  <p className="text-gray-600 text-sm">Start chatting with someone about an item to see conversations here.</p>
                </div>
              ) : (
                <div className="space-y-1 p-2">
                  {conversations.map((conversation, index) => (
                    <motion.div
                      key={conversation.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      onClick={() => setSelectedConversation(conversation)}
                      className={`p-4 rounded-lg cursor-pointer transition-all hover:bg-blue-50 ${
                        selectedConversation?.id === conversation.id ? 'bg-blue-100 border-l-4 border-blue-500' : ''
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                              <UserIcon className="w-4 h-4 text-white" />
                            </div>
                            <span className="font-medium text-gray-900 truncate">
                              {getOtherUser(conversation)}
                            </span>
                          </div>
                          <p className="text-sm font-semibold text-blue-600 mb-1">
                            {conversation.item_title}
                          </p>
                          <p className="text-sm text-gray-600 truncate">
                            {conversation.last_message || "No messages yet"}
                          </p>
                          {conversation.last_message_date && (
                            <p className="text-xs text-gray-400 mt-1">
                              {format(new Date(conversation.last_message_date), 'MMM d, HH:mm')}
                            </p>
                          )}
                        </div>
                        {getUnreadCount(conversation) > 0 && (
                          <Badge className="bg-red-500 text-white text-xs">
                            {getUnreadCount(conversation)}
                          </Badge>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Chat Area */}
          <div className="lg:col-span-2">
            {selectedConversation ? (
              <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl h-full flex flex-col">
                <CardHeader className="border-b flex-shrink-0">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setSelectedConversation(null)}
                        className="lg:hidden"
                      >
                        <ArrowLeft className="w-4 h-4" />
                      </Button>
                      <div>
                        <CardTitle className="text-lg">
                          {getOtherUser(selectedConversation)}
                        </CardTitle>
                        <p className="text-sm text-blue-600">
                          About: {selectedConversation.item_title}
                        </p>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {selectedConversation.item_type} item
                    </Badge>
                  </div>
                </CardHeader>

                {/* Messages */}
                <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
                  <AnimatePresence>
                    {messages.map((message, index) => (
                      <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`flex ${message.sender === user.email ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-xs lg:max-w-md px-4 py-2 rounded-2xl ${
                            message.sender === user.email
                              ? 'bg-blue-600 text-white'
                              : 'bg-gray-100 text-gray-900'
                          }`}
                        >
                          <p className="text-sm">{message.content}</p>
                          <div className={`flex items-center gap-1 mt-1 ${
                            message.sender === user.email ? 'justify-end' : 'justify-start'
                          }`}>
                            <span className={`text-xs ${
                              message.sender === user.email ? 'text-blue-100' : 'text-gray-500'
                            }`}>
                              {format(new Date(message.created_date), 'HH:mm')}
                            </span>
                            {message.sender === user.email && (
                              <CheckCheck className={`w-3 h-3 ${
                                message.is_read ? 'text-blue-200' : 'text-blue-300'
                              }`} />
                            )}
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </CardContent>

                {/* Message Input */}
                <div className="border-t p-4 flex-shrink-0">
                  <div className="flex gap-2">
                    <Textarea
                      placeholder="Type your message..."
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          sendMessage();
                        }
                      }}
                      className="flex-1 min-h-[40px] max-h-32 resize-none"
                    />
                    <Button
                      onClick={sendMessage}
                      disabled={!newMessage.trim() || sending}
                      className="bg-blue-600 hover:bg-blue-700 px-4"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ) : (
              <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl h-full flex items-center justify-center">
                <div className="text-center">
                  <MessageSquare className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Select a Conversation</h3>
                  <p className="text-gray-600">Choose a conversation from the left to start chatting</p>
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
