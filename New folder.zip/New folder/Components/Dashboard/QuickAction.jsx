import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { HelpCircle, MapPin, Search, User } from "lucide-react";

const actions = [
  {
    title: "Report Lost Item",
    description: "Can't find something?",
    icon: HelpCircle,
    url: "ReportLost",
    color: "from-red-500 to-pink-500"
  },
  {
    title: "Report Found Item", 
    description: "Found something?",
    icon: MapPin,
    url: "ReportFound",
    color: "from-green-500 to-emerald-500"
  },
  {
    title: "Browse Items",
    description: "Search all items",
    icon: Search,
    url: "Browse", 
    color: "from-blue-500 to-indigo-500"
  },
  {
    title: "My Items",
    description: "Manage your reports",
    icon: User,
    url: "MyItems",
    color: "from-purple-500 to-violet-500"
  }
];

export default function QuickActions() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {actions.map((action, index) => (
        <motion.div
          key={action.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <Link to={createPageUrl(action.url)}>
            <Card className="h-full hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border-0 bg-white/80 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className={`w-16 h-16 rounded-2xl bg-gradient-to-r ${action.color} flex items-center justify-center mb-4 mx-auto`}>
                  <action.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-bold text-center text-gray-900 mb-2">
                  {action.title}
                </h3>
                <p className="text-gray-600 text-center text-sm">
                  {action.description}
                </p>
              </CardContent>
            </Card>
          </Link>
        </motion.div>
      ))}
    </div>
  );
}