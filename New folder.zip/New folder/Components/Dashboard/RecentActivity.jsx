import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Calendar,
  MapPin,
  ArrowRight,
  Image as ImageIcon,
  AlertCircle,
  CheckCircle
} from "lucide-react";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";

const categoryColors = {
  electronics: "bg-blue-100 text-blue-800",
  clothing: "bg-purple-100 text-purple-800",
  books: "bg-green-100 text-green-800",
  accessories: "bg-pink-100 text-pink-800",
  keys: "bg-yellow-100 text-yellow-800",
  documents: "bg-red-100 text-red-800",
  sports_equipment: "bg-indigo-100 text-indigo-800",
  bags: "bg-orange-100 text-orange-800",
  jewelry: "bg-purple-100 text-purple-800",
  other: "bg-gray-100 text-gray-800"
};

export default function RecentActivity({ title, items, type, isLoading }) {
  const getStatusIcon = (item) => {
    if (type === 'lost') {
      return item.status === 'found' ? CheckCircle : AlertCircle;
    }
    return item.status === 'returned' ? CheckCircle : AlertCircle;
  };

  const getStatusColor = (item) => {
    if (type === 'lost') {
      return item.status === 'found' ? 'text-green-600' : 'text-red-600';
    }
    return item.status === 'returned' ? 'text-green-600' : 'text-orange-600';
  };

  if (isLoading) {
    return (
      <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
        <CardHeader>
          <Skeleton className="h-6 w-40" />
        </CardHeader>
        <CardContent className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="flex items-center space-x-4">
              <Skeleton className="w-12 h-12 rounded-lg" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-lg">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-lg font-bold text-gray-900">{title}</CardTitle>
        <Link to={createPageUrl("Browse")}>
          <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-700">
            View All
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </Link>
      </CardHeader>
      <CardContent>
        {items.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
              {type === 'lost' ? <AlertCircle className="w-8 h-8" /> : <CheckCircle className="w-8 h-8" />}
            </div>
            <p>No {type} items reported yet</p>
          </div>
        ) : (
          <div className="space-y-4">
            {items.map((item, index) => {
              const StatusIcon = getStatusIcon(item);
              return (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center space-x-4 p-3 rounded-xl hover:bg-blue-50/50 transition-colors cursor-pointer"
                >
                  <div className="relative">
                    {item.image_urls && item.image_urls.length > 0 ? (
                      <img 
                        src={item.image_urls[0]} 
                        alt={item.title}
                        className="w-12 h-12 rounded-lg object-cover"
                      />
                    ) : (
                      <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                        <ImageIcon className="w-6 h-6 text-gray-400" />
                      </div>
                    )}
                    <StatusIcon className={`w-4 h-4 ${getStatusColor(item)} absolute -top-1 -right-1 bg-white rounded-full`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-gray-900 truncate">{item.title}</h4>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge className={`text-xs ${categoryColors[item.category] || categoryColors.other}`}>
                        {item.category?.replace(/_/g, ' ')}
                      </Badge>
                      <div className="flex items-center text-xs text-gray-500">
                        <MapPin className="w-3 h-3 mr-1" />
                        {type === 'lost' ? item.location_lost : item.location_found}
                      </div>
                    </div>
                    <div className="flex items-center text-xs text-gray-400 mt-1">
                      <Calendar className="w-3 h-3 mr-1" />
                      {format(new Date(type === 'lost' ? item.date_lost : item.date_found), 'MMM d, yyyy')}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}