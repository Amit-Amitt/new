import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, Users, CheckCircle, AlertCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

const statsConfig = [
  {
    title: "Total Lost Items",
    key: "totalLost",
    icon: AlertCircle,
    color: "text-red-600",
    bgColor: "bg-red-100"
  },
  {
    title: "Total Found Items", 
    key: "totalFound",
    icon: CheckCircle,
    color: "text-green-600",
    bgColor: "bg-green-100"
  },
  {
    title: "Active Cases",
    key: "activeItems", 
    icon: Users,
    color: "text-blue-600",
    bgColor: "bg-blue-100"
  },
  {
    title: "Successful Returns",
    key: "successfulReturns",
    icon: TrendingUp,
    color: "text-purple-600", 
    bgColor: "bg-purple-100"
  }
];

export default function StatsOverview({ stats, isLoading }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statsConfig.map((config, index) => (
        <motion.div
          key={config.title}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: index * 0.1 }}
        >
          <Card className="relative overflow-hidden bg-white/70 backdrop-blur-sm border-0 shadow-lg">
            <div className={`absolute top-0 right-0 w-20 h-20 ${config.bgColor} opacity-10 rounded-full transform translate-x-6 -translate-y-6`} />
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                {config.title}
              </CardTitle>
              <div className={`${config.bgColor} p-2 rounded-lg`}>
                <config.icon className={`w-4 h-4 ${config.color}`} />
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-16" />
              ) : (
                <div className="text-2xl font-bold text-gray-900">
                  {stats[config.key]}
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}