import React from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Filter } from "lucide-react";

const categories = [
  { value: "all", label: "All Categories" },
  { value: "electronics", label: "Electronics" },
  { value: "clothing", label: "Clothing" },
  { value: "books", label: "Books" },
  { value: "accessories", label: "Accessories" },
  { value: "keys", label: "Keys" },
  { value: "documents", label: "Documents" },
  { value: "sports_equipment", label: "Sports Equipment" },
  { value: "bags", label: "Bags" },
  { value: "jewelry", label: "Jewelry" },
  { value: "other", label: "Other" }
];

const dateRanges = [
  { value: "all", label: "Any Time" },
  { value: "today", label: "Today" },
  { value: "week", label: "This Week" },
  { value: "month", label: "This Month" }
];

export default function ItemFilters({ filters, setFilters, activeTab }) {
  const statusOptions = activeTab === "lost" 
    ? [
        { value: "all", label: "All Status" },
        { value: "active", label: "Still Lost" },
        { value: "found", label: "Found" }
      ]
    : [
        { value: "all", label: "All Status" },
        { value: "available", label: "Available" },
        { value: "returned", label: "Returned" }
      ];

  return (
    <div className="flex flex-wrap gap-3">
      <div className="flex items-center gap-2 min-w-0">
        <Filter className="w-4 h-4 text-gray-500 flex-shrink-0" />
        <Select
          value={filters.category}
          onValueChange={(value) => setFilters(prev => ({ ...prev, category: value }))}
        >
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            {categories.map(cat => (
              <SelectItem key={cat.value} value={cat.value}>
                {cat.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Select
        value={filters.dateRange}
        onValueChange={(value) => setFilters(prev => ({ ...prev, dateRange: value }))}
      >
        <SelectTrigger className="w-36">
          <SelectValue placeholder="Date" />
        </SelectTrigger>
        <SelectContent>
          {dateRanges.map(range => (
            <SelectItem key={range.value} value={range.value}>
              {range.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select
        value={filters.status}
        onValueChange={(value) => setFilters(prev => ({ ...prev, status: value }))}
      >
        <SelectTrigger className="w-32">
          <SelectValue placeholder="Status" />
        </SelectTrigger>
        <SelectContent>
          {statusOptions.map(status => (
            <SelectItem key={status.value} value={status.value}>
              {status.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}