import React, { useState, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  MapPin, 
  Calendar, 
  Image as ImageIcon, 
  Phone, 
  Mail,
  AlertCircle,
  CheckCircle,
  DollarSign,
  Heart, 
  MessageSquare 
} from "lucide-react";
import { format } from "date-fns";

// Assuming these are available from an API layer or utility files.
// Please adjust these import paths if they are different in your project structure.
// For the purpose of providing a complete and functional file, I am assuming these modules exist.
import { Favorite, User } from "@/entities/all"; // Updated import
import { startConversation } from "../utils/chatUtils"; // Updated import

const categoryColors = {
  electronics: "bg-blue-100 text-blue-800",
  clothing: "bg-purple-100 text-purple-800", 
  books: "bg-green-100 text-green-800",
  accessories: "bg-pink-100 text-pink-800",
  keys: "bg-yellow-100 text-yellow-800",
  documents: "bg-red-100 text-red-800",
  sports_equipment: "bg-indigo-100 text-indigo-800",
  bags: "bg-orange-100 text-orange-800",
  jewelry: "bg-purple-100 text-purple-800",
  other: "bg-gray-100 text-gray-800"
};

export default function ItemCard({ item, type, index }) {
  const [showDetails, setShowDetails] = useState(false);
  const [isFavorited, setIsFavorited] = useState(false);
  const [user, setUser] = useState(null);
  
  const loadUserAndFavoriteStatus = useCallback(async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      // Check if item is already favorited
      const favorites = await Favorite.list(); // Fetch all favorites
      // Filter favorites by current user's email
      const userFavorites = favorites.filter(fav => fav.created_by === userData.email);
      // Check if any of user's favorites match the current item and type
      const favorited = userFavorites.some(fav => fav.item_id === item.id && fav.item_type === type);
      setIsFavorited(favorited);
    } catch (error) {
      console.error('Error loading user data or favorite status:', error);
      // Handle error, e.g., set user to null or show a message
    }
  }, [item.id, type]); // Dependencies for useCallback

  useEffect(() => {
    loadUserAndFavoriteStatus();
  }, [loadUserAndFavoriteStatus]); // Dependency for useEffect

  const toggleFavorite = async (e) => {
    e.stopPropagation(); // Prevent opening the dialog when clicking the favorite button
    
    if (!user) {
      console.warn('User not logged in. Cannot toggle favorite.');
      // Optionally, show a login prompt
      return;
    }
    
    try {
      if (isFavorited) {
        // Remove from favorites
        const favorites = await Favorite.list();
        const userFavorite = favorites.find(fav =>
          fav.created_by === user.email && 
          fav.item_id === item.id && 
          fav.item_type === type
        );
        if (userFavorite) {
          await Favorite.delete(userFavorite.id);
        }
      } else {
        // Add to favorites
        await Favorite.create({
          item_id: item.id,
          item_type: type,
          item_title: item.title,
          item_category: item.category,
          created_by: user.email // Ensure the created_by field is set
        });
      }
      setIsFavorited(!isFavorited); // Toggle local state
    } catch (error) {
      console.error('Error toggling favorite:', error);
      // Handle error, e.g., show an error message
    }
  };

  const handleContactClick = async (e) => {
    e.stopPropagation(); // Prevent opening the dialog when clicking the message button
    if (!user) {
      console.warn('User not logged in. Cannot start conversation.');
      // Optionally, show a login prompt
      return;
    }
    try {
      // Assuming startConversation handles the logic to open a chat or navigate
      await startConversation(item, type, user);
    } catch (error) {
      console.error('Error starting conversation:', error);
    }
  };
  
  const getStatusInfo = () => {
    if (type === 'lost') {
      return {
        icon: item.status === 'found' ? CheckCircle : AlertCircle,
        color: item.status === 'found' ? 'text-green-600' : 'text-red-600',
        text: item.status === 'found' ? 'Found' : 'Still Lost'
      };
    } else {
      return {
        icon: item.status === 'returned' ? CheckCircle : AlertCircle,
        color: item.status === 'returned' ? 'text-green-600' : 'text-orange-600',
        text: item.status === 'returned' ? 'Returned' : 'Available'
      };
    }
  };

  const statusInfo = getStatusInfo();
  const StatusIcon = statusInfo.icon;

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.1 }}
        onClick={() => setShowDetails(true)}
      >
        <Card className="h-full cursor-pointer hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 bg-white/80 backdrop-blur-sm border-0">
          <CardContent className="p-0">
            {/* Image */}
            <div className="relative h-48 bg-gray-100 rounded-t-lg overflow-hidden">
              {item.image_urls && item.image_urls.length > 0 ? (
                <img
                  src={item.image_urls[0]}
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <ImageIcon className="w-16 h-16 text-gray-400" />
                </div>
              )}
              {/* Category Badge */}
              <div className="absolute top-3 right-3 flex items-center gap-2">
                <Badge className={`${categoryColors[item.category] || categoryColors.other} shadow-lg border-2`}>
                  {item.category?.replace(/_/g, ' ')}
                </Badge>
              </div>
              
              {/* Favorite Button */}
              <div className="absolute top-3 left-3">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={toggleFavorite}
                  className={`bg-white/90 hover:bg-white p-2 h-8 w-8 rounded-full ${
                    isFavorited ? 'text-red-500 hover:text-red-600' : 'text-gray-400 hover:text-red-500'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${isFavorited ? 'fill-current' : ''}`} />
                </Button>
              </div>
              
              {/* Status Indicator */}
              <div className="absolute bottom-3 left-3">
                <div className={`flex items-center gap-1 px-3 py-1 rounded-full bg-white/95 shadow-md ${statusInfo.color}`}>
                  <StatusIcon className="w-4 h-4" />
                  <span className="text-sm font-semibold">{statusInfo.text}</span>
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="p-4 space-y-3">
              <div>
                <h3 className="font-bold text-lg text-gray-900 mb-1 line-clamp-1">
                  {item.title}
                </h3>
                <p className="text-gray-600 text-sm line-clamp-2">
                  {item.description}
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center text-sm text-gray-500">
                  <MapPin className="w-4 h-4 mr-2 flex-shrink-0" />
                  <span className="truncate">
                    {type === 'lost' ? item.location_lost : item.location_found}
                  </span>
                </div>
                <div className="flex items-center text-sm text-gray-500">
                  <Calendar className="w-4 h-4 mr-2 flex-shrink-0" />
                  <span>
                    {format(new Date(type === 'lost' ? item.date_lost : item.date_found), 'MMM d, yyyy')}
                  </span>
                </div>
                {type === 'lost' && item.reward_offered && (
                  <div className="flex items-center text-sm text-green-600 font-medium">
                    <DollarSign className="w-4 h-4 mr-2" />
                    <span>${item.reward_offered} reward</span>
                  </div>
                )}
              </div>

              {/* New Contact Button */}
              <div className="pt-3 border-t mt-4"> {/* Added mt-4 for spacing */}
                <Button
                  className="w-full bg-blue-600 hover:bg-blue-700 font-semibold"
                  onClick={handleContactClick}
                >
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Message {type === 'lost' ? 'Owner' : 'Finder'}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Details Dialog */}
      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-gray-900">
              {item.title}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Images */}
            {item.image_urls && item.image_urls.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {item.image_urls.map((url, idx) => (
                  <img
                    key={idx}
                    src={url}
                    alt={`${item.title} ${idx + 1}`}
                    className="w-full h-48 object-cover rounded-lg"
                  />
                ))}
              </div>
            )}

            {/* Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Description</h4>
                  <p className="text-gray-600">{item.description}</p>
                </div>
                
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Category</h4>
                  <Badge className={categoryColors[item.category] || categoryColors.other}>
                    {item.category?.replace(/_/g, ' ')}
                  </Badge>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Location</h4>
                  <div className="flex items-center text-gray-600">
                    <MapPin className="w-4 h-4 mr-2" />
                    {type === 'lost' ? item.location_lost : item.location_found}
                  </div>
                </div>
                
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Date</h4>
                  <div className="flex items-center text-gray-600">
                    <Calendar className="w-4 h-4 mr-2" />
                    {format(new Date(type === 'lost' ? item.date_lost : item.date_found), 'MMMM d, yyyy')}
                  </div>
                </div>

                {type === 'lost' && item.reward_offered && (
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Reward</h4>
                    <div className="flex items-center text-green-600 font-medium">
                      <DollarSign className="w-4 h-4 mr-2" />
                      ${item.reward_offered}
                    </div>
                  </div>
                )}

                {type === 'found' && item.handover_location && (
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Handover Location</h4>
                    <p className="text-gray-600">{item.handover_location}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Contact Info - The display of contact info remains, but the old button is removed. */}
            <div className="bg-blue-50 rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 mb-3">Contact Information</h4>
              <div className="space-y-2">
                <div className="flex items-center text-gray-600">
                  <Mail className="w-4 h-4 mr-3" />
                  <span>{item.contact_info}</span>
                </div>
                {/* The old contact button logic is now handled by the new Message button on the card itself */}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
