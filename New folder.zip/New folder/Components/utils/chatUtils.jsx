import { Conversation, User } from "@/entities/all";
import { createPageUrl } from "@/utils";

export const startConversation = async (item, itemType, user) => {
  try {
    // Check if conversation already exists
    const existingConversations = await Conversation.list();
    const existing = existingConversations.find(conv => 
      conv.item_id === item.id && 
      conv.item_type === itemType &&
      ((conv.item_owner === item.created_by && conv.inquirer === user.email) ||
       (conv.inquirer === item.created_by && conv.item_owner === user.email))
    );

    if (existing) {
      // Conversation exists, redirect to messages
      window.location.href = createPageUrl("Messages") + `?conversation=${existing.id}`;
      return;
    }

    // Create new conversation
    await Conversation.create({
      item_id: item.id,
      item_type: itemType,
      item_owner: item.created_by,
      inquirer: user.email,
      item_title: item.title,
      status: "active"
    });

    // Redirect to messages page
    window.location.href = createPageUrl("Messages");
  } catch (error) {
    console.error('Error starting conversation:', error);
    // Fallback to direct contact
    if (item.contact_info.includes('@')) {
      window.location.href = `mailto:${item.contact_info}`;
    } else {
      window.location.href = `tel:${item.contact_info}`;
    }
  }
};