// Fuzzy search utilities
export const fuzzySearch = (query, text) => {
  if (!query || !text) return false;
  
  query = query.toLowerCase().trim();
  text = text.toLowerCase();
  
  // Exact match
  if (text.includes(query)) return true;
  
  // Common typos and abbreviations
  const corrections = {
    'lapi': 'laptop',
    'lap': 'laptop', 
    'phon': 'phone',
    'fone': 'phone',
    'ipad': 'tablet',
    'airpod': 'airpods',
    'earbud': 'earbuds',
    'headfon': 'headphone',
    'compter': 'computer',
    'comuter': 'computer',
    'botle': 'bottle',
    'bottel': 'bottle',
    'watr': 'water',
    'walet': 'wallet',
    'backpac': 'backpack',
    'bac': 'bag',
    'kee': 'key',
    'kees': 'keys',
    'glases': 'glasses',
    'sunglas': 'sunglasses'
  };
  
  // Check if corrected query matches
  const corrected = corrections[query];
  if (corrected && text.includes(corrected)) return true;
  
  // Check each word separately for partial matches
  const queryWords = query.split(' ');
  const textWords = text.split(' ');
  
  return queryWords.some(queryWord => 
    textWords.some(textWord => 
      textWord.startsWith(queryWord) || 
      queryWord.startsWith(textWord) ||
      levenshteinDistance(queryWord, textWord) <= 2
    )
  );
};

// Calculate edit distance between two strings
const levenshteinDistance = (str1, str2) => {
  const matrix = [];
  
  for (let i = 0; i <= str2.length; i++) {
    matrix[i] = [i];
  }
  
  for (let j = 0; j <= str1.length; j++) {
    matrix[0][j] = j;
  }
  
  for (let i = 1; i <= str2.length; i++) {
    for (let j = 1; j <= str1.length; j++) {
      if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1
        );
      }
    }
  }
  
  return matrix[str2.length][str1.length];
};

export const getSearchSuggestions = (query) => {
  const suggestions = [];
  const commonItems = [
    'laptop', 'phone', 'iphone', 'android', 'tablet', 'ipad',
    'airpods', 'earbuds', 'headphones', 'charger', 'cable',
    'wallet', 'purse', 'backpack', 'bag', 'book', 'notebook',
    'keys', 'keychain', 'glasses', 'sunglasses', 'watch',
    'water bottle', 'coffee mug', 'umbrella', 'jacket', 'hoodie'
  ];
  
  if (query.length < 2) return suggestions;
  
  query = query.toLowerCase();
  
  commonItems.forEach(item => {
    if (item.includes(query) || fuzzySearch(query, item)) {
      suggestions.push(item);
    }
  });
  
  return suggestions.slice(0, 5);
};