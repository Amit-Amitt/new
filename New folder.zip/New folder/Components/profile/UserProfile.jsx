import React, { useState } from "react";
import { User } from "@/entities/User";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  User as UserIcon,
  Mail,
  Shield,
  Edit,
  Save,
  X,
  CheckCircle
} from "lucide-react";
import { motion } from "framer-motion";

export default function UserProfile({ user, onUpdate }) {
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    full_name: user?.full_name || "",
    phone: user?.phone || "",
    dorm_room: user?.dorm_room || "",
    year: user?.year || "",
    major: user?.major || ""
  });
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  const handleSave = async () => {
    setSaving(true);
    setMessage("");
    
    try {
      await User.updateMyUserData(editData);
      setMessage("Profile updated successfully!");
      setIsEditing(false);
      if (onUpdate) onUpdate();
    } catch (error) {
      setMessage("Error updating profile. Please try again.");
    }
    setSaving(false);
  };

  const handleCancel = () => {
    setEditData({
      full_name: user?.full_name || "",
      phone: user?.phone || "",
      dorm_room: user?.dorm_room || "",
      year: user?.year || "",
      major: user?.major || ""
    });
    setIsEditing(false);
    setMessage("");
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-2xl mx-auto"
    >
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
        <CardHeader className="text-center pb-6">
          <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <UserIcon className="w-10 h-10 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-900">
            {user?.full_name || "User Profile"}
          </CardTitle>
          <p className="text-gray-600">{user?.email}</p>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {message && (
            <Alert className={message.includes("success") ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}>
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>{message}</AlertDescription>
            </Alert>
          )}

          {/* Basic Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                Email Address
              </Label>
              <Input 
                value={user?.email || ""} 
                disabled 
                className="bg-gray-100"
              />
              <p className="text-xs text-gray-500">Email cannot be changed</p>
            </div>

            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Shield className="w-4 h-4" />
                Role
              </Label>
              <Input 
                value={user?.role || "user"} 
                disabled 
                className="bg-gray-100"
              />
            </div>
          </div>

          {/* Editable Fields */}
          <div className="space-y-6 pt-4 border-t">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold text-gray-900">Personal Information</h3>
              {!isEditing ? (
                <Button
                  onClick={() => setIsEditing(true)}
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  <Edit className="w-4 h-4" />
                  Edit Profile
                </Button>
              ) : (
                <div className="flex gap-2">
                  <Button
                    onClick={handleSave}
                    disabled={saving}
                    className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
                  >
                    <Save className="w-4 h-4" />
                    {saving ? "Saving..." : "Save"}
                  </Button>
                  <Button
                    onClick={handleCancel}
                    variant="outline"
                    className="flex items-center gap-2"
                  >
                    <X className="w-4 h-4" />
                    Cancel
                  </Button>
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="full_name">Full Name</Label>
                <Input
                  id="full_name"
                  value={isEditing ? editData.full_name : (user?.full_name || "")}
                  onChange={(e) => setEditData(prev => ({...prev, full_name: e.target.value}))}
                  disabled={!isEditing}
                  className={!isEditing ? "bg-gray-50" : ""}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  value={isEditing ? editData.phone : (user?.phone || "")}
                  onChange={(e) => setEditData(prev => ({...prev, phone: e.target.value}))}
                  disabled={!isEditing}
                  placeholder="Your phone number"
                  className={!isEditing ? "bg-gray-50" : ""}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="dorm_room">Dorm/Room</Label>
                <Input
                  id="dorm_room"
                  value={isEditing ? editData.dorm_room : (user?.dorm_room || "")}
                  onChange={(e) => setEditData(prev => ({...prev, dorm_room: e.target.value}))}
                  disabled={!isEditing}
                  placeholder="e.g., Smith Hall 204"
                  className={!isEditing ? "bg-gray-50" : ""}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="year">Year</Label>
                <Input
                  id="year"
                  value={isEditing ? editData.year : (user?.year || "")}
                  onChange={(e) => setEditData(prev => ({...prev, year: e.target.value}))}
                  disabled={!isEditing}
                  placeholder="e.g., Sophomore, Junior"
                  className={!isEditing ? "bg-gray-50" : ""}
                />
              </div>

              <div className="md:col-span-2 space-y-2">
                <Label htmlFor="major">Major</Label>
                <Input
                  id="major"
                  value={isEditing ? editData.major : (user?.major || "")}
                  onChange={(e) => setEditData(prev => ({...prev, major: e.target.value}))}
                  disabled={!isEditing}
                  placeholder="e.g., Computer Science, Psychology"
                  className={!isEditing ? "bg-gray-50" : ""}
                />
              </div>
            </div>
          </div>

          {/* Tips */}
          <div className="bg-blue-50 rounded-lg p-4 mt-6">
            <h4 className="font-semibold text-blue-900 mb-2">Profile Tips</h4>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Keep your contact information up to date for better communication</li>
              <li>• Adding your dorm/room helps people return items to you directly</li>
              <li>• Your profile information helps build trust in the community</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}