import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Home, Search, Plus, User, HelpCircle, MapPin, MessageSquare, Heart } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";

const navigationItems = [
  {
    title: "Dashboard",
    url: createPageUrl("Dashboard"),
    icon: Home,
  },
  {
    title: "Browse Items",
    url: createPageUrl("Browse"),
    icon: Search,
  },
  {
    title: "Messages",
    url: createPageUrl("Messages"),
    icon: MessageSquare,
  },
  {
    title: "Favorites",
    url: createPageUrl("Favorites"),
    icon: Heart,
  },
  {
    title: "Report Lost",
    url: createPageUrl("ReportLost"),
    icon: HelpCircle,
  },
  {
    title: "Report Found",
    url: createPageUrl("ReportFound"),
    icon: MapPin,
  },
  {
    title: "My Items",
    url: createPageUrl("MyItems"),
    icon: User,
  },
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <style>{`
          :root {
            --primary: 219 94% 65%;
            --primary-foreground: 0 0% 98%;
            --secondary: 210 40% 98%;
            --secondary-foreground: 222 84% 5%;
            --accent: 210 40% 96%;
            --accent-foreground: 222 84% 5%;
            --background: 0 0% 100%;
            --foreground: 222 84% 5%;
            --muted: 210 40% 96%;
            --muted-foreground: 215 16% 47%;
            --border: 214 32% 91%;
            --ring: 219 94% 65%;
          }
        `}</style>
        
        <Sidebar className="border-r border-blue-100 bg-gradient-to-b from-blue-50 to-white">
          <SidebarHeader className="border-b border-blue-100 p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
                <Search className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-xl text-gray-900">Lost & Found</h2>
                <p className="text-sm text-blue-600 font-medium">Campus Recovery Hub</p>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-4">
            <SidebarGroup>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navigationItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        className={`hover:bg-blue-50 hover:text-blue-700 transition-all duration-300 rounded-xl mb-2 h-12 ${
                          location.pathname === item.url 
                            ? 'bg-gradient-to-r from-blue-50 to-blue-100 text-blue-700 shadow-sm' 
                            : 'text-gray-700'
                        }`}
                      >
                        <Link to={item.url} className="flex items-center gap-4 px-4 py-3">
                          <item.icon className="w-5 h-5" />
                          <span className="font-medium">{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup className="mt-8">
              <div className="px-4 py-6 bg-gradient-to-r from-blue-500 to-blue-600 rounded-2xl text-white">
                <div className="flex items-center gap-3 mb-3">
                  <Plus className="w-5 h-5" />
                  <span className="font-semibold">Quick Actions</span>
                </div>
                <p className="text-blue-100 text-sm mb-4">
                  Lost something? Found something? Report it quickly!
                </p>
                <div className="space-y-2">
                  <Link to={createPageUrl("ReportLost")}>
                    <button className="w-full bg-white/20 hover:bg-white/30 rounded-lg px-3 py-2 text-sm font-medium transition-all">
                      Report Lost Item
                    </button>
                  </Link>
                  <Link to={createPageUrl("ReportFound")}>
                    <button className="w-full bg-white/20 hover:bg-white/30 rounded-lg px-3 py-2 text-sm font-medium transition-all">
                      Report Found Item
                    </button>
                  </Link>
                </div>
              </div>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="border-t border-blue-100 p-4">
            <div className="flex items-center gap-3 px-2">
              <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                <User className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-gray-900 text-sm truncate">College Student</p>
                <p className="text-xs text-gray-500 truncate">Helping our campus community</p>
              </div>
            </div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col bg-gray-50">
          <header className="bg-white border-b border-gray-200 px-6 py-4 md:hidden shadow-sm">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-gray-100 p-2 rounded-lg transition-colors duration-200" />
              <h1 className="text-xl font-bold text-gray-900">Lost & Found</h1>
            </div>
          </header>

          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
